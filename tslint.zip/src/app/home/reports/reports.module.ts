import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ScrollbarModule } from 'ngx-scrollbar';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReportsRoutingModule } from './reports.routing';

import { ReportsComponent } from './reports.component';
import { ProcessComponent } from './process/process.component';
import { UnderwritingComponent } from './underwriting/underwriting.component';

@NgModule({
  imports: [
    CommonModule,
    NgxDatatableModule,
    ScrollbarModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ReportsRoutingModule
  ],
  declarations: [
    ReportsComponent,
    ProcessComponent,
    UnderwritingComponent
    ]
})
export class ReportsModule { }
