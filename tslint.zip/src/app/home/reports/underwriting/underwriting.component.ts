import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-underwriting',
  templateUrl: './underwriting.component.html',
  styleUrls: ['./underwriting.component.scss']
})
export class UnderwritingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
