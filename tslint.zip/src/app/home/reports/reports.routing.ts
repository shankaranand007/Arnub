import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReportsComponent } from './reports.component';
import { ProcessComponent } from './process/process.component';
import { UnderwritingComponent } from './underwriting/underwriting.component';
import { appConst } from '../../app.const';
const routes: Routes = [
    {
        path: '', component: ReportsComponent,
        children: [
            { path: appConst.ROUTES.PROCESS, component: ProcessComponent },
            { path: appConst.ROUTES.UNDERWRITING, component: UnderwritingComponent },
            { path: '', redirectTo: appConst.ROUTES.PROCESS, pathMatch: 'full' }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ReportsRoutingModule { }
