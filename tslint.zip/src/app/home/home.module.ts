import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ScrollbarModule } from 'ngx-scrollbar';
import { TagInputModule } from 'ngx-chips';
import { HomeRoutingModule } from './home.routing';
import { HomeComponent } from './home.component';
import { MenuComponent } from '../shared/layout/menu.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeService } from './home.service';
import { SharedModule } from '../shared/shared.module';
import { ClaimsModule } from './claims/claims.module';
import { MasterModule } from './master/master.module';
import { WorkdatatableComponent } from './workdatatable/workdatatable.component';
import { ReportsModule } from './reports/reports.module';
import { NotesComponent } from './notes/notes.component';
import { ModalModule } from 'ngx-bootstrap';
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TagInputModule,
        NgxDatatableModule,
        ScrollbarModule,
        HomeRoutingModule,
        SharedModule,
        ClaimsModule,
        MasterModule,
        ReportsModule,
        ModalModule.forRoot()
    ],
    exports: [],
    declarations: [
        HomeComponent,
        MenuComponent,
        DashboardComponent,
        WorkdatatableComponent,
        NotesComponent,
        
    ],
    providers: [
        HomeService
    ],
})
export class HomeModule { }
