import { Component, OnInit,TemplateRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { SharedModule } from '../../shared/shared.module';
import { appConst} from '../../app.const';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {
  items: any[]; 
  modalRef: BsModalRef;
  constructor( private BsService: BsModalService) {

    this.items = Array(20).fill(0);
   }


   openModal(template: TemplateRef<any>){
    console.log("hi testing ");
    this.modalRef = this.BsService.show(template);
   
  }
  ngOnInit() {
  }

}
