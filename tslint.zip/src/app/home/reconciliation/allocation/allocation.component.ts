import { Component, OnInit } from '@angular/core';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { appConst } from '../../../app.const';
@Component({
  selector: 'app-allocation',
  templateUrl: './allocation.component.html',
  styleUrls: ['./allocation.component.scss']
})
export class AllocationComponent implements OnInit {

  constructor( public route: Router, public ActivateRoute: ActivatedRoute ) { }

  ngOnInit() {
  }

  checksURL(URL) {
    return (window.location.href).substr((window.location.href).lastIndexOf('/') + 1).trim();
  }
}
