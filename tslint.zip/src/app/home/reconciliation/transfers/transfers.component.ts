import { Component, OnInit } from '@angular/core';
import { ReconciliationService} from '../reconciliation.service';

@Component({
  selector: 'app-transfers',
  templateUrl: './transfers.component.html',
  styleUrls: ['./transfers.component.scss']
})
export class TransfersComponent implements OnInit {
  txnData:any = {};

  public trxnGrid: any = {
    rows: [],
    cols: []
  }
  
  constructor( public reconcilation : ReconciliationService) {
    this.transferdetails ();
   }
 
  ngOnInit() {
  }

  transferdetails() {
    this.reconcilation.transferdata(this.txnData).subscribe(
       res => {
         this.trxnGrid.rows = res;
       },
       error =>{

       }
    );

}
}
