import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { ReconciliationRoutingModule } from './reconciliation-routing.module';
import { AllocationComponent } from './allocation/allocation.component';
import { TransfersComponent } from './transfers/transfers.component';
import { ReconciliationComponent } from './reconciliation.component';
import { ScrollbarModule } from 'ngx-scrollbar';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReconciliationService} from '../reconciliation/reconciliation.service';

@NgModule({
  imports: [
    CommonModule,
    ReconciliationRoutingModule,
    SharedModule,
    ScrollbarModule,
    NgxDatatableModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [AllocationComponent, TransfersComponent,ReconciliationComponent],
  providers: [
    ReconciliationService
],
})
export class ReconciliationModule { }
