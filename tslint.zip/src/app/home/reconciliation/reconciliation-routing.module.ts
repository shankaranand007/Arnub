import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllocationComponent } from './allocation/allocation.component';
import { appConst } from '../../app.const';
import { TransfersComponent } from './transfers/transfers.component';
import { ReconciliationComponent } from './reconciliation.component';




const routes: Routes = [
  {
    path: '', component: ReconciliationComponent,

    children: [
      { path:  appConst.ROUTES.ALLOCATION,  component: AllocationComponent },
      { path: appConst.ROUTES.TRANSFERS ,  component: TransfersComponent },
      {path: '', redirectTo:appConst.ROUTES.TRANSFERS,pathMatch:'full'}
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReconciliationRoutingModule { }
