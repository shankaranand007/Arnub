import { ReconciliationModule } from './reconciliation.module';

describe('ReconciliationModule', () => {
  let reconciliationModule: ReconciliationModule;

  beforeEach(() => {
    reconciliationModule = new ReconciliationModule();
  });

  it('should create an instance', () => {
    expect(reconciliationModule).toBeTruthy();
  });
});
