import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import  {map} from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ReconciliationService {

  constructor(public http :HttpClient) { }

  transferdata(transfer){
    return this.http.get('./assets/mocks/transfer.json').pipe(map((res: any) => {
              return res;
               }));
              }
}
