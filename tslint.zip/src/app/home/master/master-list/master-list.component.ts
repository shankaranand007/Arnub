import { Component, OnInit } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ViewChild } from '@angular/core';
import { MasterService } from '../master.service';
import { Router, ActivatedRoute } from '@angular/router';
import { TemplateRef } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
@Component({
  selector: 'app-master-list',
  styleUrls: ['./list.scss'],
  templateUrl: './master-list.component.html',
})
export class MasterListComponent implements OnInit {
  enableSummary = true;
  @ViewChild(DatatableComponent) table: DatatableComponent;
  @ViewChild('cancel') public cancel: TemplateRef<any>;
  public dialogRef: MatDialogRef<any>;
  rows = []
  pagevalue = []
  summaryPosition = 'top';
  model: any = {};
objectKeys = Object.keys;
  public claimsGrid = {
    cols: [
      { prop: 'Master Policy No', name: 'Master Policy No' },
      { prop: 'Customer Name', name: 'Customer Name' },
      { prop: 'Product Type', name: 'Product Type' },
      { prop: 'Version', name: 'Version' },
      { prop: 'UpdateDate', name: 'UpdateDate' },
      { prop: 'Actions', name: 'Actions' }
    ],
  }

  cities = [
    { id: 1, name: 'Vilnius' },
    { id: 2, name: 'Kaunas' },
    { id: 3, name: 'Pavilnys', disabled: true },
    { id: 4, name: 'Pabradė' },
    { id: 5, name: 'Klaipėda' }
  ];
  data = [];
  filteredData = [];
  constructor(public masterService: MasterService,public route:Router,public dialog: MatDialog,) { }

  ngOnInit() {
    this.getData(1, null)
  }
  searchClaims(){
    
  }
  policyDetails(policyNumber,version){
    this.route.navigate(['/home/master/create',policyNumber+version])
  // (version != 0)?this.route.navigateByUrl('/home/master/create/a/`policyNumber`',version):this.route.navigateByUrl('/home/master/create/a/'+policyNumber)   
  }
  onFooterPage(info) {
    this.getData(info.page, this.model);
  }
  policyFilter(policyno) {
    this.getData(1, this.model);
  }
  customerNameFilter(customername) {
    this.getData(1, this.model);
  }
  onProductType(selectProduct) {
    this.getData(1, this.model);
  }
  onPolicyType(selectPolicy) {
    this.getData(1, this.model);
  }

  getData(offset, params) {
    this.masterService.pagelist(offset, params)
      .subscribe(data => {
        this.rows = (data['policyList'].length) ? data['policyList'] : [{ "ulm_MST_REF_NO": "", "ULM_PROD_ID": "", "ulm_CNAME": "" }];
        this.pagevalue = data['count'];
        // this.data = data['policyList'];
        // this.filteredData = data['policyList'];
        console.log(this.rows);

      })
  }
  resetMaster(){
    this.model={}
  }
  filterDatatable(event) {
    const val = event.target.value.toLowerCase();
    const temp = this.filteredData.filter(function (d) {
      let sortvalue = d.firstName.toLowerCase().indexOf(val) !== -1 || [];
      console.log("sort", sortvalue)
      return d.firstName.toLowerCase().indexOf(val) !== -1 || !val;
    });
    this.rows = temp;
    this.table.offset = 0;
  }

  toggleExpandRow(row) {
    this.table.rowDetail.toggleExpandRow(row);
  }
  onDetailToggle(event) {
    console.log('Detail Toggled', event);
  }
  onCancel() {
    this.dialogRef = this.dialog.open(this.cancel);
  }
  onCloseCancel(){
  this.dialogRef.close(this.cancel);
}
}
