import { Component, OnInit, ViewChild, ElementRef, TemplateRef, Output, Input, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ScrollbarComponent } from 'ngx-scrollbar';
import { MatDatepicker } from '@angular/material/datepicker';
import { Router,ActivatedRoute } from '@angular/router';
import { OwlMomentDateTimeModule } from 'ng-pick-datetime-moment';
import { DateTimeAdapter, OWL_DATE_TIME_FORMATS, OWL_DATE_TIME_LOCALE } from 'ng-pick-datetime';
import { MomentDateTimeAdapter } from 'ng-pick-datetime-moment';
import { TranslateService } from "@ngx-translate/core";
import * as moment from 'moment';
import { ProgressbarConfig } from 'ngx-bootstrap/progressbar';
import { MasterService } from './../master.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export function getProgressbarConfig(): ProgressbarConfig {
  return Object.assign(new ProgressbarConfig(), { animate: true, striped: true, max: 150 });
}
export const MY_CUSTOM_FORMATS = {
  datePickerInput: 'DD/MM/YYYY',
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY',
  parseInput: 'LL LT',
  fullPickerInput: 'DD/MM/YYYY kk:mm:ss'
};

@Component({
  selector: 'app-create-master',
  templateUrl: './create-master.component.html',
  styleUrls: ['./create-master.component.scss'],
  providers: [{ provide: ProgressbarConfig, useFactory: getProgressbarConfig },
  { provide: DateTimeAdapter, useClass: MomentDateTimeAdapter, deps: [OWL_DATE_TIME_LOCALE] },
  { provide: OWL_DATE_TIME_FORMATS, useValue: MY_CUSTOM_FORMATS }]
})

export class CreateMasterComponent implements OnInit {
  firstFormGroup:any;
  secondFormGroup:any;
  thirdFormGroup:any;
  fourthFormGroup:any;
  
  
  division:any;
  department:any;
  sob:any;
  custName:any;
  poBoxNo:any;
  addr1:any;
  ddlCountry:any;
  custMobNo:any;
  custPhoneNo:any;
  custFacNo:any;
  custEmailId:any;
  ddlPolicyTerms:any;
  ddlPrefix:any;
  firstName:any;
  lastName:any;
  designation:any;
  poBoxNoPOC:any;
  addr1POC:any;
  mobNoPOC:any;
  custPhoneNoPOC:any;
  custFaxNoPOC:any;
  emailIDPOC:any;
  custFaxNo:any;
  custEmailID:any;
  middlename:any;
  middleName:any;

  ddlEmpCat:any;
  ddlCov:any;
  sharePerc:any;

  param2: any;
  param1: any;
  public dialogRef: MatDialogRef<any>;
  message: string;
  @ViewChild('confirmModel') public confirm: TemplateRef<any>;
  @ViewChild('reOpenClaimsModel') public reOpenClaimsModel: TemplateRef<any>;
  @ViewChild('addnewPolicyForm') public addnewPolicyForm: TemplateRef<any>;
  @ViewChild('coverageForm') public coverageForm: TemplateRef<any>;
  @ViewChild('newCoInsurer') public newCoInsurer: TemplateRef<any>;
  @ViewChild('cancel') public cancel: TemplateRef<any>;
  

  @ViewChild(ScrollbarComponent) scrollRef: ScrollbarComponent;

  @Output() action = new EventEmitter();
  @Input() actionCB: Function;
  public isLinear: boolean = true;
  public isActive: boolean = true;
  public isSubmittedFirstForm: Boolean = false;
  public isSubmittedSecondForm: Boolean = false;
  public isSubmittedThirdForm: Boolean = false;
  public isSubmittedFourthForm: Boolean = false;
  public showConfirmationPopUp: Boolean = false;
  public pattern: any = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/

  constructor(public formBuilder: FormBuilder, public dialog: MatDialog,
    public router: Router, public masterService: MasterService,public activatedRoute: ActivatedRoute,
    // public modal: Modal, public translate: TranslateService,
  ) { }

  coverageData: any = {};
  policyForm = [];
  coInsDet = [];
  public coverageGrid: any = {
    rows: [],
    cols: [
    ],
  }

  public custDet = {
    firstFormGroup: this.formBuilder.group({
      division: ['', [Validators.required, Validators.maxLength(100)]],
      department: ['', [Validators.required, Validators.maxLength(100)]],
      sob: ['', Validators.required],
      custName: ['', [Validators.required, Validators.maxLength(20)]],
      poBoxNo: ['', [Validators.required, Validators.maxLength(9)]],
      addr1: ['', [Validators.required, Validators.maxLength(100)]],
      addr2: [''],
      addr3: [''],
      name_format:[''],
      ddlPrefix_choose: [''],
      toggle: [''],
      addr2POC: [''],
      addr3POC: [''],
      country: [''],
      ddlCountry: ['', Validators.required],
      custMobNo: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(7), Validators.maxLength(10), Validators.pattern('^[0-9]*$')])],
      custPhoneNo: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(7), Validators.maxLength(20), Validators.pattern('^[0-9]*$')])],
      custFaxNo: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(7), Validators.maxLength(20), Validators.pattern('^[0-9]*$')])],
      custEmailID: ['', [Validators.required, Validators.pattern(this.pattern)]],
      ddlPolicyTerms: ['', Validators.required],
      ddlPrefix: ['', Validators.required],
      firstName: ['', [Validators.required, Validators.maxLength(20)]],
      middlename: ['', [Validators.maxLength(20)]],
      lastName: ['', [Validators.required, Validators.maxLength(20)]],
      designation: ['', [Validators.required, Validators.maxLength(20)]],
      mobNoPOC: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(7), Validators.maxLength(10), Validators.pattern('^[0-9]*$')])],
      emailIDPOC: ['', [Validators.required, Validators.pattern(this.pattern)]],
      poBoxNoPOC: ['', [Validators.required, Validators.maxLength(9)]],
      addr1POC: ['', [Validators.required, Validators.maxLength(100)]],
      custPhoneNoPOC: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(7), Validators.maxLength(20), Validators.pattern('^[0-9]*$')])],
      custFaxNoPOC: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(7), Validators.maxLength(20), Validators.pattern('^[0-9]*$')])],
    }),
    secondFormGroup: this.formBuilder.group({
      ddlEmpCat: ['', Validators.required],popcoverage:[''],
      ddlCov: ['', Validators.required],vat:['', Validators.required],
      coverageAmt: ['', [Validators.required, Validators.maxLength(10)]],
    }),
    thirdFormGroup: this.formBuilder.group({
      addnew_policy:['']
    }),
    fourthFormGroup: this.formBuilder.group({
      sharePerc: ['', [Validators.required, Validators.maxLength(3)]],addnew_coverage:['']
    })
  }

  getCoverageData() {
    this.masterService.getCreateMasterDate(this.coverageData, this.policyForm, this.coInsDet).subscribe(
      res => {
        this.coverageGrid.rows = res['coverage'];
        this.policyForm = res['policyForm'];
        this.coInsDet = res['coInsDet'];
      },
      err => {

      }
    );
  }
  addnewPolicy(){
    this.dialogRef = this.dialog.open(this.addnewPolicyForm);
  }
  coveragefunction(){
    this.dialogRef = this.dialog.open(this.coverageForm);
  }
  public onDiscardMasterDet = function () {
    this.custDet = {};
    this.custDet = false;
    this.masterService.getCreateMasterDate = false;
    window.history.back();
  }

  public onEnableNextFirstForm() {
    this.scrollRef.scrollYTo(1, 100);
    this.isSubmittedFirstForm = true;
  }

  public onEnableSecondNextStep() {
    this.getCoverageData();
    this.scrollRef.scrollYTo(1, 100);
    this.isSubmittedSecondForm = true;
  }

  public onEnableThirdNextStep() {
    this.getCoverageData();
    this.scrollRef.scrollYTo(1, 100);
    this.isSubmittedThirdForm = true;
  }

  public onSaveFourthStep() {
    this.scrollRef.scrollYTo(1, 100);
    this.isSubmittedFourthForm = true;
    this.showConfirmationPopUp = true;
    if (this.isSubmittedFourthForm = true) {
      this.dialogRef = this.dialog.open(this.confirm);
      // this.modal.open(ConfirmationComponent, overlayConfigFactory({ dialogClass: 'common-modal', data: this }, BSModalContext));
    }
  }
  change(value){}
  onSaveFirstStep(){}
  ngOnInit() {
    
    // ####### 0 => VIEW
     // ####### 1 => VERSION VIEW
      // ####### 3 => CREATE MASTER

      this.param1 = this.activatedRoute.snapshot.params.id.toString();
      this.param2 = this.param1.substr(this.param1.length - 1);
      if(this.param2 == 1 || this.param2 == 0 ){
        this.custDet.firstFormGroup.disable();
        this.custDet.secondFormGroup.disable();
        this.custDet.thirdFormGroup.disable();
        this.custDet.fourthFormGroup.disable();
      }
        else{
          this.custDet.firstFormGroup.enable();
          this.custDet.secondFormGroup.enable();
          this.custDet.thirdFormGroup.enable();
          this.custDet.fourthFormGroup.enable();

        }
    this.getCoverageData();
  }

  public onEnablePrevious() {
    this.scrollRef.scrollYTo(1, 100);
  }
  master_Coverage_addNew(){
    this.dialogRef = this.dialog.open(this.newCoInsurer);
  }
  showCloseModal() {
    // this.dialogRef = this.dialog.open(this.confirm);
  }
  showReOpenModal() {
    this.dialogRef = this.dialog.open(this.reOpenClaimsModel);
  }
  onCancel() {
    this.dialogRef = this.dialog.open(this.cancel);
  }
  onCloseCancel(filter){
    let closeValue = (filter == 'cancel')?this.cancel:(filter == 'newCoInsurer')?this.newCoInsurer:(filter == 'reOpenClaimsModel')? this.reOpenClaimsModel :(filter == 'addnewPolicyForm')?  this.addnewPolicyForm: (filter == 'coverageForm')?this.coverageForm:this.confirm;
    this.dialogRef.close(closeValue);
}
onCreateOrUpdateRole(){}
onSelectRole(valuie){}
}
