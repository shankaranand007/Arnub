import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterListComponent } from './master-list/master-list.component';
import { CreateMasterComponent } from './create-master/create-master.component';
import { appConst } from '../../app.const';

const routes: Routes = [
  {path:'',redirectTo:appConst.ROUTES.LIST,pathMatch:'full'},
  {path:appConst.ROUTES.LIST,component:MasterListComponent},
  {path:appConst.ROUTES.CREATE,component:CreateMasterComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterRoutingModule { }
