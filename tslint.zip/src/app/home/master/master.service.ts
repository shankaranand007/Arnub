import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable()
export class MasterService {

  constructor(public http: HttpClient) { }

  public getCreateMasterDate(coverages, policyForm, coInsDet) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.get('./assets/mocks/createMasters.mock.json', { headers: headers });
  }

  public getmasterlist() {
    return this.http.get('../../assets/mocks/test.json');
  }
  pagelist(offset, data) {
    console.log("data", data);
    data = (data == null) ? [] : data;
    var value = {
      "selectPolicyType": (data.policy) ? data.policy : "",
      "masterPolicyNo": (data.policyno) ? data.policyno : "",
      "customerName": (data.customername) ? data.customername : "",
      "productType": (data.product) ? data.product : ""
    }

    console.log("value", value);
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    // return this.http.post('/api/searchPolicy?offset=' + offset, value, { headers: headers })
    return this.http.get('../../assets/mocks/test.json');
  }
}
