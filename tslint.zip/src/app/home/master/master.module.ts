import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MasterListComponent } from './master-list/master-list.component';
import { CreateMasterComponent } from './create-master/create-master.component';
import { MasterRoutingModule } from './master-routing.module';
import { MatStepperModule } from '@angular/material/stepper';
import { MasterService } from './master.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ScrollbarModule } from 'ngx-scrollbar';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TagInputModule } from 'ngx-chips';
import { MasterComponent } from './master.component';

@NgModule({
  imports: [
    CommonModule,
    MasterRoutingModule,
    NgxDatatableModule,
    ScrollbarModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    TagInputModule,
    MatStepperModule
  ],
  declarations: [MasterListComponent, CreateMasterComponent, MasterComponent],
  providers: [
    MasterService
  ],
})
export class MasterModule { }
