import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ClaimsModule } from './claims/claims.module';
import { MasterModule } from './master/master.module';
import { appConst } from '../app.const';
import { ReconciliationModule } from './reconciliation/reconciliation.module';
import { WorkdatatableComponent } from './workdatatable/workdatatable.component';
import { ReportsModule } from './reports/reports.module';
import {NotesComponent } from './notes/notes.component';

const homeRoutes: Routes = [
    {
        path: '', component: HomeComponent,
        children: [
            { path: appConst.ROUTES.DASHBOARD, component: DashboardComponent },
            { path: appConst.ROUTES.MASTER, loadChildren: () => MasterModule },
            { path: appConst.ROUTES.CLAIMS, loadChildren: () => ClaimsModule },
            { path: appConst.ROUTES.REPORTS, loadChildren: () => ReportsModule },
            { path: appConst.ROUTES.WORKBASKET, component: WorkdatatableComponent },
            { path: appConst.ROUTES.RECONCILIATION, loadChildren: () => ReconciliationModule },
            { path:appConst.ROUTES.NOTES,component:NotesComponent}
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(homeRoutes)],
    exports: [RouterModule],
})
export class HomeRoutingModule { }
