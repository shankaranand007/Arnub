import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { AppService } from '../app.service';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';


@Injectable()
export class HomeService {
    private keyAccess = new BehaviorSubject({"access":"NO"});

    Access = this.keyAccess.asObservable();

    accessPermission(value) {
        this.keyAccess.next(value);
      }
    

    constructor(public http: HttpClient) { }

    // API Call on Table data 

    public getWorkBasket(works, offset) {

        return this.http.get('/api/work/user/2?offset=' + offset, works).pipe(map((res: any) => {

            return res;
        }));

    }

    // Export API Call

    public workExport() {
        return this.http.post('/api/work/user/1/export', {}, {
            responseType: "blob"
        }).map((res: any) => {
            return new Blob([res], { type: 'application/vnd.ms-excel' })
        }
        );
    }

    //   Search API call

    public searchdata(works, offset) {
        return this.http.post('/api/work/user/2/search?offset=' + offset, works).pipe(map((res: any) => {
            return res;
        }));

    }

    public getWorkList(){  
    return this.http.get('./assets/mocks/workbasket.json');
    }

}

