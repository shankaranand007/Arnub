import { Component, OnInit } from '@angular/core';
import { HomeService } from '../home.service';
import { FormControl } from '@angular/forms';
import { WorkList } from './../../shared/models/works';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from './../../app.service';

@Component({
  selector: 'app-workdatatable',
  templateUrl: './workdatatable.component.html',
  styleUrls: ['./workdatatable.component.scss']
})
export class WorkdatatableComponent implements OnInit {
  maxDate:Date;
  minDate:Date;
  icon: boolean = true;
  iconclick(){
      this.icon = !this.icon;
    }

  // Current date code
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());

  //let variable declaration..>
  offset: any = 0;
  // works: any = {};
  works: any={};
  workBasket: any;
  public workGrid: any = {
    rows: [],
    cols: [
      { prop: 'refno', name: 'refno' },
      { prop: 'workname', name: 'workname' },
      { prop: 'activity', name: 'activity' },
      { prop: 'lossdate', name: 'lossdate' },
      { prop: 'appdate', name: 'appdate' }
    ],
    total: 0
  }
  constructor(public homeservice: HomeService,public route:Router,public appService:AppService) {
    this.getWorkList();
  }
  // /home/claims/summary/payment
  ngOnInit() {
  }
  onSelectClaim(row) {  
    console.log("row is clicked commit");
  }
  claimPayment(value){
    this.appService.setClaimNoSession(value);
    this.homeservice.accessPermission({"access":"YES"});
    this.route.navigateByUrl("/home/claims/summary/payment");
   
  }
  getWorkList(){
    this.homeservice.getWorkList()
    .subscribe(data=>{console.log(data['rows']);this.workGrid = data;})
  }
  // getWorkBasket() {
  //   this.homeservice.getWorkBasket(this.works, this.offset).subscribe(
  //     res => {
  //       this.workGrid.rows = res.records;
  //       this.workGrid.total = res.total;
  //     },
  //     err => {
  //     }
  //   );
  // }

  // Export data Downloading xls file

  workBasketExport() {
    this.homeservice.workExport().subscribe(
      res => {
        this.workExport(res)
      },
      err => {
      }
    );
  }
  workExport(data) {
    var link = document.createElement('a');
    link.href = window.URL.createObjectURL(data);
    link.download = "workReport.xlsx";
    link.click();
  }

  //export is done 
 

  // search data

   searchdata( ){

   this.homeservice.searchdata(this.works,this.offset).subscribe(
     res => {
        this.workGrid.rows = res.records;
        this.workGrid.total = res.total;

    },err =>{

     }
   )
   }

// search data done



// reset data
resetdata(){
  this.works = new WorkList();
}


  // Footer pagination 

  onFooterPage(event) {
    console.log(event)
    this.offset = (event.page - 1)
  }

}
