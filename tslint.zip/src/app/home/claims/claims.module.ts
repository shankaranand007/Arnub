import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClaimListComponent } from './claim-list/claim-list.component';

import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ScrollbarModule } from 'ngx-scrollbar';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TagInputModule } from 'ngx-chips';

import { ClaimsSummaryComponent } from './claims-summary/claims-summary.component';
import { ClaimRegistrationComponent } from './claims-summary/claim-registration/claim-registration.component';
import { ClaimDocumentComponent } from './claims-summary/claim-document/claim-document.component';
import { ClaimPaymentComponent } from './claims-summary/claim-payment/claim-payment.component';
import { ClaimRecoveryComponent } from './claims-summary/claim-recovery/claim-recovery.component';
import { ClaimsRoutingModule } from './claims-routing.module';
import { DocumentModule } from './claims-summary/document/document.module';
import { ClaimsService } from './claims.service';
import { ClaimInsurerComponent } from './claims-summary/claim-insurer/claim-insurer.component';
// import { CovalentFileModule } from '@covalent/core';
// import { ClaimHeaderComponent } from './claims-summary/claim-header/claim-header.component';
import { ClaimsComponent } from './claims.component';


@NgModule({
  imports: [
    CommonModule,
    NgxDatatableModule,
    DocumentModule,
    ScrollbarModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    TagInputModule,
    ClaimsRoutingModule,
    

  ],
  declarations: [
    ClaimListComponent,
    ClaimsComponent,
    ClaimsSummaryComponent,
    ClaimRegistrationComponent,
    ClaimDocumentComponent,
    ClaimPaymentComponent,
    ClaimRecoveryComponent,
    ClaimInsurerComponent
  ],
  providers: [ClaimsService]
})
export class ClaimsModule { }
