import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClaimListComponent } from './claim-list/claim-list.component';
import { ClaimsSummaryComponent } from './claims-summary/claims-summary.component';
import { ClaimRegistrationComponent } from './claims-summary/claim-registration/claim-registration.component';
import { ClaimDocumentComponent } from './claims-summary/claim-document/claim-document.component';
import { ClaimPaymentComponent } from './claims-summary/claim-payment/claim-payment.component';
import { ClaimRecoveryComponent } from './claims-summary/claim-recovery/claim-recovery.component';
import { ClaimInsurerComponent } from './claims-summary/claim-insurer/claim-insurer.component';
import { DocumentComponent } from './claims-summary/document/document.component';
import { UploadComponent } from './claims-summary/document/upload/upload.component';
import { HomeComponent } from './claims-summary/document/home/home.component';
import { FolderComponent } from './claims-summary/document/folder/folder.component';
import { FileComponent } from './claims-summary/document/file/file.component';
import { appConst } from '../../app.const';
const routes: Routes = [
    { path: '', redirectTo: appConst.ROUTES.CLAIMSLIST, pathMatch: 'full' },
    { path: appConst.ROUTES.CLAIMSLIST, component: ClaimListComponent },
    {
        path: appConst.ROUTES.CLAIMSSUMMARY, component: ClaimsSummaryComponent,
        children: [
            { path: appConst.ROUTES.CLAIMSREGISTER, component: ClaimRegistrationComponent },
            {
                path: 'document/:id', component: DocumentComponent, children: [
                    {
                        path: 'upload',
                        component: UploadComponent,
                        pathMatch: 'full'
                    },
                    {
                        path: '',
                        component: HomeComponent,
                        children: [
                            {
                                path: '',
                                component: FolderComponent,
                                pathMatch: 'full'
                            },
                            {
                                path: ':folder',
                                component: FileComponent
                            }
                        ]
                    }
                ]
            },
            { path: appConst.ROUTES.CLAIMSPAYMENT, component: ClaimPaymentComponent },
            { path: appConst.ROUTES.CLAIMSINSURER, component: ClaimInsurerComponent },
            { path: appConst.ROUTES.CLAIMSRECOVERY, component: ClaimRecoveryComponent },
            { path: '', redirectTo: appConst.ROUTES.CLAIMSREGISTER, pathMatch: 'full' }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ClaimsRoutingModule { }
