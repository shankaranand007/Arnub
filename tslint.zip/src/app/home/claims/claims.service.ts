import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { ResponseContentType } from '@angular/http';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class ClaimsService {

  private messageSource = new BehaviorSubject({});
  currentMessage = this.messageSource.asObservable();

  constructor(public http: HttpClient) { }

  changeMessage(message) {
    this.messageSource.next(message);
  }

  public getClaimsList(claims, query) {
    // return this.http.get('./assets/mocks/claims-list.mock.json').pipe(map((res: any) => {
    //   return res;
    // }));
    return this.http.post('/api/claims/search?offset=' + query.offset + '&limit=' + query.limit, claims).pipe(map((res: any) => {
      return res;
    }));
  }

  public getClaimsSearchOptionsList() {
    // return this.http.get('./assets/mocks/claims-search-option-list.json').pipe(map((res: any) => {
    //   return res;
    // }));
    return this.http.get('/api/claims/getClaimCriteriaDetails?companyId=DIC').pipe(map((res: any) => {
      return res;
    }));
  }

  public getClaimsPaymentDetails() {
    return this.http.get('./assets/mocks/claims-payment.json').pipe(map((res: any) => {
      return res;
    }));
  }

  public getClaimsInsurerDetails() {
    return this.http.get('./assets/mocks/claims-insurer.json').pipe(map((res: any) => {
      return res;
    }));
  }

  public getClaimsRecoveryDetails() {
    return this.http.get('./assets/mocks/claims-recovery.json').pipe(map((res: any) => {
      return res;
    }));
  }

  public claimsExport(exportData) {
    return this.http.post('/api/claims/export', exportData, {
      responseType: 'blob'
    }).map((res: any) => {
      return new Blob([res], { type: 'application/vnd.ms-excel' });
    }
    );
  }
  claimRegestrationDetails(id) {
    return this.http.get('/api/claims/getclaim?claimNo=' + id);
  }

  public claimAction(data, action) {
    return this.http.post('/api/claims/' + action, data).pipe(map((res: any) => {
      return res;
    }));
  }
  public claimUpdate(id, reson, description) {
    let value = { "reason": reson, "reasonDesc": description }
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post('/api/claims/reason'+id, value, { headers: headers }).pipe(map((res: any) => {
      return res;
    }));
  }
  public getClaimsActionStatus(action) {
    return this.http.get('/api/claims/' + action + '/reason').pipe(map((res: any) => {
      return res;
    }));
  }
  public getClaimsActions(claimNo) {
    return this.http.get('/api/claims/getClaimActions?claimNo=' + claimNo).pipe(map((res: any) => {
      return res;
    }));
  }
}
