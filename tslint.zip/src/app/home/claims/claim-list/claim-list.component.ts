import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ClaimsService } from './../claims.service';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MAT_MOMENT_DATE_FORMATS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from 'moment';
import { ClaimsList, ClaimsListQueryParam } from './../../../shared/models/claims';
import { ThrowStmt } from '@angular/compiler';
import { appConst } from '../../../app.const';
import { AppService } from './../../../app.service';
@Component({
  selector: 'app-claim-list',
  templateUrl: './claim-list.component.html',
  styleUrls: ['./claim-list.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})

export class ClaimListComponent implements OnInit {
  object = Object.keys;
  claimSelectAll = false;
  claimFromDate: any;
  claimToDate: any;
  department: any = {};
  division: any = {};
  statusTypes: any = {};
  workerTypes: any = {};
  sponsorTypes: any = {};
  public claimsGrid: any = {
    rows: [],
    cols: [],
  };
  totalCount: number;
  payload: any[] = [];
  claims: ClaimsList = new ClaimsList();
  queryParam: ClaimsListQueryParam = new ClaimsListQueryParam();
  messages = { emptyMessage: appConst.CLAIMS.NODATAMESSAGE };

  constructor(public router: Router, public claimsService: ClaimsService, public appService: AppService) {
    this.getClaimsSearchOptionList();
    this.setListQueryParam();
    this.setClaimsDate();
    this.getClaims();
  }
  claimSearch() { }
  ngOnInit() { }

  setListQueryParam() {
    this.queryParam.limit = appConst.CLAIMS.LIMIT;
    this.queryParam.offset = appConst.CLAIMS.OFFSET;
  }

  setClaimsDate() {
    this.claimToDate = (new FormControl(moment(new Date())));
    this.claims.toDate = moment.utc(new Date()).format(appConst.DATE_FORMAT.API);
    this.claimFromDate = new FormControl(moment(this.claimToDate).subtract(appConst.CLAIMS.SUBTRACTMONTH, 'months'));
    this.claims.fromDate = moment.utc((this.claimToDate)).subtract(1, 'months').format(appConst.DATE_FORMAT.API);
  }

  onSelectClaim(value) {
    this.appService.setClaimNoSession(value);
    this.router.navigateByUrl('/home/claims/summary/registration');
  }

  getClaims() {
    this.claimsService.getClaimsList(this.claims, this.queryParam).subscribe(
      res => {
        this.totalCount = res.total;
        this.claimsGrid.rows = res.records;
        this.setClaimSelectAll();
      }
    );
  }

  getClaimsSearchOptionList() {
    this.claimsService.getClaimsSearchOptionsList().subscribe(
      res => {
        if (!this.isEmpty(res.department)) { this.department = res.department; }
        if (!this.isEmpty(res.division)) { this.division = res.division; }
        if (!this.isEmpty(res.statusTypes)) { this.statusTypes = res.statusTypes; }
        if (!this.isEmpty(res.workerTypes)) { this.workerTypes = res.workerTypes; }
        if (!this.isEmpty(res.sponsorTypes)) { this.sponsorTypes = res.sponsorTypes; }
      },
      err => {
        this.appService.showToasterErrMsg(err);
      }
    );
  }

  setClaimSelectAll(event?) {
    this.claimsGrid.rows.map(
      data => {
        return this.claimSelectAll ? data.select = true : data.select = false;
      }
    );
  }

  setClaimSelect(event, value) {
    this.claimsGrid.rows.forEach(element => {
      if (element.claimNo === value) { element.select = event.checked; }
    });
  }

  getClaimSelected() {
    this.payload = [];
    this.claimsGrid.rows.forEach(element => {
      if (element.select) { this.payload.push(element.claimNo); }
    });
  }

  exportClaims() {
    this.getClaimSelected();
    if (this.payload.length > 0) {
      this.claimsService.claimsExport(this.payload).subscribe(
        res => {
          this.claimSelectAll = false;
          this.setClaimSelectAll();
          this.exportExcel(res);
        },
        err => {
          this.appService.showToasterErrMsg(err);
        }
      );
    }
  }
  exportExcel(data) {
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(data);
    link.download = appConst.CLAIMS.EXPORTEXCELNAME + '.xlsx';
    link.click();
  }

  resetClaimsDate() {
    this.setClaimsDate();
    this.getClaims();
  }

  resetClaims() {
    this.claims = new ClaimsList();
    this.fromDateEvent('', this.claimFromDate);
    this.toDateEvent('', this.claimToDate);
    this.getClaims();
  }

  fromDateEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.claims.fromDate = moment(event.value).format(appConst.DATE_FORMAT.API);
    this.getClaims();
  }

  toDateEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.claims.toDate = moment(event.value).format(appConst.DATE_FORMAT.API);
    this.getClaims();
  }

  changeLossDateEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.claims.claimLaunchDate = moment.utc(event.value).format(appConst.DATE_FORMAT.API);
  }

  onFooterPage(event) {
    this.queryParam.offset = (event.page - 1);
    this.getClaims();
  }

  searchClaims(event) {
    this.getClaims();
  }

  claimOffsetSearch(event) {
    this.getClaims();
  }

  isEmpty(value) {
    return (value === undefined || value === null) ? true : false;
  }

}
