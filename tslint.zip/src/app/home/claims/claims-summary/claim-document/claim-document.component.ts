import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-document',
  templateUrl: './claim-document.component.html',
  styleUrls: ['./claim-document.component.scss']
})
export class ClaimDocumentComponent implements OnInit {
  public claimsGrid = {
    rows: [],
    cols: [
      { prop: 'notificationNo', name: 'Notification #' },
      { prop: 'firstName', name: 'Insured Name' },
      { prop: 'insurerName', name: 'Insurer Name' },
      { prop: 'lossDate', name: 'Loss Date' },
      { prop: 'reportedDate', name: 'Reported Date' },
      { prop: 'status', name: 'Status' }
    ],
    size: 100,
    count: 100,
    totalPages: 1,
    pageNumber: 1
  };
  constructor() { }

  ngOnInit() {
  }

}
