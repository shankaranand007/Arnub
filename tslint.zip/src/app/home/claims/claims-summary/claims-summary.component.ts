import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AppService } from './../../../app.service';
import { ClaimsService } from './../claims.service';
import { appConst } from '../../../app.const';
@Component({
  selector: 'app-claims-summary',
  templateUrl: './claims-summary.component.html',
  styleUrls: ['./claims-summary.component.scss']
})
export class ClaimsSummaryComponent implements OnInit {
  params: string;
  @ViewChild('closeClaimsModel') public closeClaimsModel: TemplateRef<any>;
  @ViewChild('reOpenClaimsModel') public reOpenClaimsModel: TemplateRef<any>;
  @ViewChild('declineClaimsModel') public declineClaimsModel: TemplateRef<any>;
  public dialogRef: MatDialogRef<any>;
  status: any = [] as Object;
  statusName: any = [];
  constructor(
    public route: Router,
    public ActivateRoute: ActivatedRoute,
    public dialog: MatDialog,
    private appService: AppService,
    private claimsService: ClaimsService) { }

  ngOnInit() {
    this.params = this.appService.getClaimNoSession();
    this.getClaimActionName();
  }
  checksURL(URL) {
    return window.location.href.substr(window.location.href.lastIndexOf('/') + 1).trim();
  }
  openModal(value) {
    switch (value) {
      case appConst.CLAIMS.REOPENCLAIM:
        this.showReOpenModal(appConst.CLAIMS.REOPEN);
        break;
      case appConst.CLAIMS.DECLINECLAIM:
        this.showDeclineModal(appConst.CLAIMS.DECLINE);
        break;
      case appConst.CLAIMS.CLOSECLAIM:
        this.showCloseModal(appConst.CLAIMS.CLOSE);
        break;
    }
  }
  showCloseModal(action) {
    this.getClaimsActionStatus(action);
    this.dialogRef = this.dialog.open(this.closeClaimsModel);
  }
  showReOpenModal(action) {
    this.getClaimsActionStatus(action);
    this.dialogRef = this.dialog.open(this.reOpenClaimsModel);
  }
  showDeclineModal(action) {
    this.getClaimsActionStatus(action);
    this.dialogRef = this.dialog.open(this.declineClaimsModel);
  }
  closeDialog() {
    this.dialogRef.close();
  }
  getClaimsActionStatus(action) {
    this.claimsService.getClaimsActionStatus(action).subscribe(
      data => {
        this.status = data;
      }
    );
  }

  claimAction(closeData, action) {
    this.closeDialog();
    this.claimsService.claimAction(closeData.value, action).subscribe(
      data => {
        this.appService.showToasterSuccessMsg(data);
        this.getClaimActionName();
        if (data.success) {
          this.appService.showToasterErrMsg(data.message);
        }
      }
    );
  }
  getClaimActionName() {
    this.claimsService.getClaimsActions(this.params).subscribe(
      responce => {
        this.statusName = responce;
      }
    );
  }

  action() {
    if (this.statusName.length <= 0) {
      this.appService.showToasterErrMsg('Cliam is closed');
    }
  }

}
