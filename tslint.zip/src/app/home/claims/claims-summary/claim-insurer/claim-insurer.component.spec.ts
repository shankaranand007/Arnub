import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimInsurerComponent } from './claim-insurer.component';

describe('ClaimInsurerComponent', () => {
  let component: ClaimInsurerComponent;
  let fixture: ComponentFixture<ClaimInsurerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimInsurerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimInsurerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
