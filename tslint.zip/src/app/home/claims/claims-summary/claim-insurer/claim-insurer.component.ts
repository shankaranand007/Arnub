import { Component, OnInit } from '@angular/core';
import { ClaimsService } from './../../claims.service';
import { AppService } from './../../../../app.service';

@Component({
  selector: 'app-claim-insurer',
  templateUrl: './claim-insurer.component.html',
  styleUrls: ['./claim-insurer.component.scss']
})
export class ClaimInsurerComponent implements OnInit {

  insurerDetails: any = {} as Object;

  constructor(private claimsService: ClaimsService, private appService: AppService) {
    this.getInsurerDetails();
  }

  ngOnInit() {
  }

  getInsurerDetails() {
    this.claimsService.getClaimsInsurerDetails().subscribe(
      res => {
        this.insurerDetails = res;
      },
      err => {
        this.appService.showToasterErrMsg(err);
      }
    );
  }

}
