import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ClaimsService } from './../../claims.service';
import { AppService } from './../../../../app.service';
@Component({
  selector: 'app-claim-recovery',
  templateUrl: './claim-recovery.component.html',
  styleUrls: ['./claim-recovery.component.scss']
})
export class ClaimRecoveryComponent implements OnInit {
  @ViewChild('employerModel') private employerModel: TemplateRef<any>;
  @ViewChild('revisionHistory') private revisionHistory: TemplateRef<any>;
  private dialogRef: MatDialogRef<any>;
  recoveryDetails: any = {} as Object;
  constructor(private dialog: MatDialog, private claimsService: ClaimsService, private appService: AppService) {
    this.getRecoveryDetails();
  }

  ngOnInit() {
  }

  createRecovery() {
    this.dialogRef = this.dialog.open(this.employerModel);
  }

  openRevisionHistory() {
    this.dialogRef = this.dialog.open(this.revisionHistory);
  }

  closeDialog() {
    this.dialogRef.close();
  }

  getRecoveryDetails() {
    this.claimsService.getClaimsRecoveryDetails().subscribe(
      res => {
        this.recoveryDetails = res.recoveryDetails;
      },
      err => {
        this.appService.showToasterErrMsg(err);
      }
    );
  }
}

