import { Component, OnInit, Input } from '@angular/core';
import{ClaimsService} from '../../claims.service';
import { Subscription }   from 'rxjs/Subscription';

@Component({
  selector: 'app-claim-header',
  templateUrl: './claim-header.component.html',
  styleUrls: ['./claim-header.component.scss']
})
export class ClaimHeaderComponent implements OnInit {

  header: any;
  @Input()
  show: boolean = false;
  subscription: Subscription;
  constructor(public ClaimsService:ClaimsService) { 
  }

  ngOnInit() {
    this.ClaimsService.currentMessage.subscribe(message => {console.log("msg",message);this.header = message});
  }

}
