import { Component, OnInit } from '@angular/core';
import { ClaimsService } from './../../claims.service';
import { HomeService } from '../../../home.service';
import { AppService } from './../../../../app.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-claim-payment',
  templateUrl: './claim-payment.component.html',
  styleUrls: ['./claim-payment.component.scss']
})
export class ClaimPaymentComponent implements OnInit {

  assignPermision: string;
  paymentDetails: any = {} as Object;
  paymentReview: any;
  paymentApprove: any;
  review: any = {};
  subscription: Subscription;
  approval: any = {};
  reviewControl: Boolean = false;
  approvelControl: Boolean = false;
  constructor(private claimsService: ClaimsService, private appService: AppService, public homeService: HomeService) {
    this.getPaymentDetails();
  }

  ngOnInit() {
    this.homeService.Access.subscribe(data => { this.assignPermision = data.access })
  }

  getPaymentDetails() {
    this.claimsService.getClaimsPaymentDetails().subscribe(
      res => {
        this.paymentDetails = res;
      },
      err => {
        this.appService.showToasterErrMsg(err);
      }
    );
  }
  changeReview(amount, settled, outstading) {
    this.reviewControl = !this.reviewControl;
    this.review.amount = amount;
    this.review.settled = settled;
    this.review.outstandingAmount = outstading;
  }
  savePaymentReview() {
    this.reviewControl = !this.reviewControl;
  }
  approvelEdit(amount, settled, outstading) {
    this.approvelControl = !this.approvelControl;
    this.approval.amount = amount;
    this.approval.settled = settled;
    this.approval.outstandingAmount = outstading;
  }
  saveApprovalReview() {
    this.approvelControl = !this.approvelControl;
  }
  ngOnDestroy() {
    this.homeService.accessPermission({ "access": "NO" });
    console.log("end")
  }
}
