import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { appConst } from '../../../../app.const';
import { AppService } from "../../../../app.service";
@Component({
  selector: 'document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.scss']
})
export class DocumentComponent implements OnInit {

  constructor(public appService: AppService,
    public activatedRoute: ActivatedRoute,
    public router: Router) { }
  public docMenuFlag: boolean = true;
  // public initDocuments() {
  //   this.docMenuFlag = this.appService.getPermission(appConst.INSURER_PAGE_ACTION_NAME.INS_DOCS_VW.pageName, appConst.ACCESS_TYPE.CAN_VIEW);
  // }

  // public getObservableData() {
  //   this.appService.getRoleObserve().subscribe((data) => {
  //     if (data.indexOf(this.docMenuUrl) > -1 || (this.router.url).indexOf(this.docMenuUrl) > -1) {
  //       this.initDocuments();
  //     }
  //     else if (data.indexOf(this.docRegulatorUrl) > -1 || (this.router.url).indexOf(this.docRegulatorUrl) > -1) {
  //       this.initDocuments();
  //     }
  //   })
  // }

  ngOnInit() {
    // this.getObservableData();
  }
}
