import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ResponseContentType } from '@angular/http';
import { map } from 'rxjs/operators';

@Injectable()
export class DocumentService {

  constructor(public http: HttpClient) { }


  public uploadDocument(data, file) {
    const formData: FormData = new FormData();
    formData.append('metadata', data);
    formData.append('documents', file);
    return this.http.post('/api/dms/upload-multiple', formData);
  }

  public getDocuments(claimNo) {
    return this.http.get('/api/dms/metadata?entityRefId=' + claimNo + '&entityRefType=Claim').pipe(
      map(responce => {
        return responce;
      })
    );
  }

  deleteDocument(id) {
    return this.http.delete('/api/dms/document/' + id).map((res: any) => {
      return res;
    }
    );
  }

  public downloadDocument(id) {
    return this.http.get('/api/dms/document/' + id, {
      responseType: 'blob'
    }).map((res: any) => {
      return res;
    }
    );
  }

}
