import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  ViewChild,
  TemplateRef
} from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { DocumentService } from '../document.service';
import { AppService } from './../../../../../app.service';
import { saveAs } from 'file-saver/FileSaver';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'file',
  templateUrl: './file.component.html',
  styleUrls: ['./file.component.scss']
})
export class FileComponent implements OnInit {

  @Output() onReset = new EventEmitter<any>();
  @ViewChild('deleteFileAlert') public deleteFileAlert: TemplateRef<any>;
  claimNo: any;
  fileList: any = [];
  noFiles: Boolean = false;
  tempFile: any;


  constructor(
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private documentService: DocumentService,
    private appService: AppService,
    public dialog: MatDialog
  ) {

    this.claimNo = this.appService.getClaimNoSession();
    this.getDocuments();
  }

  ngOnInit() { }

  getDocuments() {
    this.noFiles = false;
    this.documentService.getDocuments(this.claimNo).subscribe(data => {
      this.fileList = data;
      this.getFileStatus();
    },
      err => {
        this.getFileStatus();
      }
    );
  }

  getFile(file) {
    const fileId = file.gridFSId;
    this.documentService.downloadDocument(fileId).subscribe(
      (response: any) => {
        const contentType = response.type;
        const blob = new Blob([response], { type: contentType });
        const filename = file.fileName;
        saveAs(blob, filename);
      }
    );
  }

  deleteFile(file) {
    const fileId = file.gridFSId;
    this.documentService.deleteDocument(fileId).subscribe(
      (response: any) => {
        this.getDocuments();
      },
      err => {
        this.appService.showToasterErrMsg(err);
      }
    );
  }

  getFileStatus() {
    if (this.fileList.length <= 0) {
      this.noFiles = true;
    }
  }

  goBack() {
    this.onReset.emit();
  }

  deleteConfirm(file) {
    this.tempFile = file;
    this.dialog.open(this.deleteFileAlert);
  }

  closeDialog() {
    this.dialog.closeAll();
  }
  okDialog() {
    this.deleteFile(this.tempFile);
    this.closeDialog();
  }

}
