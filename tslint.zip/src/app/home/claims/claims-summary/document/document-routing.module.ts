import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UploadComponent } from './upload/upload.component';
import { FileComponent } from './file/file.component';
import { FolderComponent } from './folder/folder.component';
import { DocumentComponent } from './document.component';

const routes: Routes = [
  {
    path: 'asa',
    component: DocumentComponent,
    children: [
      {
        path: 'upload',
        component: UploadComponent,
        pathMatch: 'full'
      },
      {
        path: '',
        component: HomeComponent,
        children: [
          {
            path: '',
            component: FolderComponent,
            pathMatch: 'full'
          },
          {
            path: ':folder',
            component: FileComponent,
            pathMatch: 'full'
          },
          {
            path: ':id/:folder',
            component: FileComponent,
            pathMatch: 'full'
          }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DocumentRoutingModule { }
