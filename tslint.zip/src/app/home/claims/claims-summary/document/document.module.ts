import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import 'rxjs/Rx'

import { DocumentRoutingModule } from './document-routing.module';
import { DocumentComponent } from './document.component';
import { UploadComponent } from './upload/upload.component';
import { FolderComponent } from './folder/folder.component';
import { FileComponent } from './file/file.component';
import { HomeComponent } from './home/home.component';
import { ScrollbarModule } from 'ngx-scrollbar';
// import { CovalentFileModule } from '@covalent/core';
import { SharedModule } from '../../../../shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { DocumentService } from './document.service';

import { ClaimHeaderComponent } from '../claim-header/claim-header.component';

@NgModule({
  imports: [
    CommonModule,
    DocumentRoutingModule,
    ScrollbarModule,

    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    Ng4LoadingSpinnerModule.forRoot(),
    ProgressbarModule.forRoot()
  ], exports: [ClaimHeaderComponent],
  declarations: [DocumentComponent, UploadComponent, FolderComponent, FileComponent, HomeComponent, ClaimHeaderComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [DocumentService]

})
export class DocumentModule { }
