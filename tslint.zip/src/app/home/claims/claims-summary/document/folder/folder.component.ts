import { Component, OnInit } from '@angular/core';
// import { OutboundService } from '../../insurer/outbound/outbound.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DocumentService } from '../document.service';

@Component({
  selector: 'folder',
  templateUrl: './folder.component.html',
  styleUrls: ['./folder.component.scss']
})
export class FolderComponent implements OnInit {

  public claim: any = {};
  folderList: any;
  noDocs: Boolean = false;
  claimNo: any;

  constructor(

    public activatedRoute: ActivatedRoute,
    public documentService: DocumentService,
    public router: Router
  ) { }




  ngOnInit() {

    // if (this.activatedRoute.snapshot.params.id) {
    //   this.getClaims();
    // } else {
    //   this.getFolderCount();
    // }

  }

 

  
  

  public getClaimById = (claimId) => {
    // this.outboundService.getClaimById(claimId).subscribe(
    //   res => {
    //     this.claim = res;
    //     if (this.claim.claimNo != null) {
    //       this.claimNo = this.claim.claimNo;
    //     } else {
    //       this.claimNo = this.claim.notificationNo;
    //     }
    //     this.getFolderCount(this.claimNo);
    //   }, err => {
    //     /* this.claimNo = claimId; */
    //   }
    // )
  }

  public getClaims() {
    let claimId = this.activatedRoute.snapshot.params.id;
    this.getClaimById(claimId);
    /* this.getFolderCount(claimId); */
  }

  public getFolderCount(id?: Number) {
    // this.documentService.getDocsCount(id ? id : 0).subscribe(
    //   (folders) => {
    //     this.folderList = folders;
    //   },
    //   (err) => {
    //     this.noDocs = true;
    //   }
    // );
  }

  public openFolder(folder) {
    this.router.navigate(['any']);
    /* this.router.navigateByUrl('/folder'); */
  }

}
