import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DocumentService } from '../document.service';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { AppService } from '../../../../../app.service';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(public fb: FormBuilder,
    public docService: DocumentService,
    public appService: AppService,
    public route: Router,
    public activatedRoute: ActivatedRoute) { }

  ngOnInit() { }

}
