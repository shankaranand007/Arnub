import { Component, OnInit } from '@angular/core';
import { DocumentService } from '../document.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ProgressbarConfig } from 'ngx-bootstrap/progressbar';
import { AppService } from '../../../../../app.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { appConst } from '../../../../../app.const';

export function getProgressbarConfig(): ProgressbarConfig {
  return Object.assign(new ProgressbarConfig(), { animate: true, striped: true, max: 150 });
}

@Component({
  selector: 'upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss'],
  providers: [{ provide: ProgressbarConfig, useFactory: getProgressbarConfig }]
})
export class UploadComponent implements OnInit {
  file: File;
  meta: any;
  claim: any;
  claimId: any;
  docType: String;
  claimNo: String;
  commonDocs: Boolean = false;
  partyType: any;
  public selectedDocType: string = 'DL';
  public showScanView: boolean = false;
  uploadSucceed: Boolean = false;
  resultKeys: string[];
  result: any[];
  isFileSelected: Boolean = false;
  firstTime: Boolean = true;
  wholeResult: any;
  isSelected: Boolean = false;
  isUploaded: Boolean = false;
  process: Boolean = false;
  isFile: Boolean = false;
  maxFileSize: Number = 5242880;
  acceptedFormats: Array<String> = appConst.CLAIMS.UPLOADIMAGEACCEPTFORMAT;
  fileDescription: any;

  constructor(public docService: DocumentService,
    public route: Router,
    public appService: AppService,
    public activatedRoute: ActivatedRoute,
    public _location: Location,
    public spinnerService: Ng4LoadingSpinnerService) {
    this.claimNo = this.appService.getClaimNoSession();
  }

  selectEvent(evt) {
    this.file = evt;
  }

  uploadFile() {
    this.appService.setBusy();
    if (this.docType) {
      this.meta = {
        "entityRefId": this.claimNo,
        "entityRefType": "Claim",
        "partyType": this.partyType,
        "documentType": this.docType,
        "description": this.fileDescription
      };

      let metaString = JSON.stringify(this.meta);
      this.docService.uploadDocument(metaString, this.file)
        .finally(() => { this.appService.resetBusy()})
        .subscribe(
          (result: any) => {
            this._location.back();
          },
          (err) => {
            this.appService.resetBusy();
          }
        );
    } else {
      this.appService.resetBusy();
      this.appService.showToasterErrMsg('Select Document Type');
    }
  }

  docTypeFn(evt) {
    this.docType = evt.value;
  }

  partyTypeFn(evt) {
    this.partyType = evt.value;
  }


  dragFile(evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.isFile = true;
    let files = evt.dataTransfer.files;
    if (files.length > 0) {
      this.isFile = true;
    }
  }

  dragLeave(evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.isFile = false;
  }

  dropFile(evt) {
    evt.preventDefault();
    evt.stopPropagation();
    let files = evt.dataTransfer.files;
    if (files.length > 0) {
      this.isFile = false;
      this.file = files[0];
      if (this.checkFormat(this.file)) {
        if (this.checkSize(this.file)) {
          this.isSelected = true;
        } else {
          this.cancelFile();
        }
      } else {
        this.cancelFile();
      }
    }
  }

  browseFile(evt) {
    let files = evt.target.files;
    if (files.length > 0) {
      this.file = files[0];
      if (this.checkFormat(this.file)) {
        if (this.checkSize(this.file)) {
          this.isSelected = true;
        } else {
          this.cancelFile();
        }
      } else {
        this.cancelFile();
      }
    }
  }

  cancelFile() {
    this.file = null;
    this.isSelected = false;
    this.process = false;
    this.isUploaded = false;
  }

  checkFormat(file: File) {
    if (this.acceptedFormats.indexOf(file.type) > -1) {
      return true;
    } else {
      this.appService.showToasterErrMsg('This file is not supported');
      return false;
    }
  }

  checkSize(file: File) {
    if (file.size >= this.maxFileSize) {
      this.appService.showToasterErrMsg('File Size should not exceed 5MB');
      return false;
    } else {
      return true;
    }
  }

  ngOnInit() {
    // this.commonDocs = true;
    this.commonDocs = false;
  }


  public urltoFile(url, filename, mimeType) {
    return (fetch(url)
      .then(function (res) { return res.arrayBuffer(); })
      .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
    );
  }
}
