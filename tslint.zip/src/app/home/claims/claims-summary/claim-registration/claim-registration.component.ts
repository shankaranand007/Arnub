import { Component, OnInit } from '@angular/core';
import { ClaimsService } from '../../claims.service';
import { ViewChild } from '@angular/core';
import { ElementRef } from '@angular/core';

@Component({
  selector: 'app-claim-registration',
  templateUrl: './claim-registration.component.html',
  styleUrls: ['./claim-registration.component.scss']
})
export class ClaimRegistrationComponent implements OnInit {
  @ViewChild('claimresonn') reason:ElementRef; 
  @ViewChild('claimdescription') description:ElementRef; 
  claimDescription:boolean=false;
  claimReason:boolean=false;
  model:any={};
  id: string;
  regData: any = {} as Object;
  public claimsGrid = {
    rows: [],
    cols: [
      { prop: 'notificationNo', name: 'Notification #' },
      { prop: 'firstName', name: 'Insured Name' },
      { prop: 'insurerName', name: 'Insurer Name' },
      { prop: 'lossDate', name: 'Loss Date' },
      { prop: 'reportedDate', name: 'Reported Date' },
      { prop: 'status', name: 'Status' }
    ],
    size: 100,
    count: 100,
    totalPages: 1,
    pageNumber: 1
  };
  params: string;
  constructor(public claimDatas: ClaimsService) { this.id = JSON.parse(sessionStorage.getItem('claim-no')); this.getData();}

  ngOnInit() {
   

  }
  getData() {
    this.claimDatas.claimRegestrationDetails(this.id)
    .subscribe(data=>{
      console.log("full value",data);
      this.regData = data;
      this.claimDatas.changeMessage(this.regData['claimDetails'])
    });
  }
  descriptionEdit(value){
    this.claimDescription = !this.claimDescription;
    this.model.claimDescription = value;
  }
  descriptionSave(){
    this.claimDescription = !this.claimDescription;
    this.claimDatas.claimUpdate(this.id,this.regData.lossDetails.claimReason,this.description.nativeElement.value).subscribe(data=>{
      (data == 'OK')?this.getData():console.log("not ok");
    })
  }
  reasonEdit(reason){
    this.claimReason = !this.claimReason;
    this.model.claimReason = reason;
  }
  reasonSave(){
    this.claimReason = !this.claimReason;
    this.claimDatas.claimUpdate(this.id,this.reason.nativeElement.value,this.regData.lossDetails.claimDescription).subscribe(data=>{
      console.log(data);
      (data['success'] == true)?this.getData():console.log("not ok");
    })
  }
}
