import { Directive, HostListener, ElementRef } from '@angular/core';

@Directive({
    selector: '[alphaOnly]'
})
export class AlphaOnlyDirective {

    public el: HTMLInputElement;

    public regex: RegExp = new RegExp(/^[a-zA-Z]+$/);
    public specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowRight', 'ArrowLeft', 'Delete'];

    constructor(public elementRef: ElementRef) { }

    @HostListener('keydown', ['$event'])
    public onKeyDown(event: KeyboardEvent) {
        if (this.specialKeys.indexOf(event.key) !== -1) {
            return;
        }
        const currentValue: string = this.elementRef.nativeElement.value;
        const enteredValue: string = currentValue.concat(event.key);
        if (enteredValue && !String(enteredValue).match(this.regex)) {
            event.preventDefault();
        }
    }

}
