import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap';
import {
  MatSelectModule,
  MatFormFieldModule,
  MatInputModule,
  MatIconModule,
  MatCheckboxModule,
  MatChipsModule,
  MatCardModule,
  MatRadioModule,
  MAT_CHECKBOX_CLICK_ACTION,
  MatNativeDateModule,
  MatSlideToggleModule,
  MatMenuModule,
  MatDialogModule,
  MatDatepickerModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatExpansionModule,
  MatTabsModule
} from '@angular/material';

@NgModule({
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    MatIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatChipsModule,
    MatCardModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatMenuModule,
    MatDialogModule,
    MatDatepickerModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatExpansionModule,
    MatExpansionModule,
    MatTabsModule,
    ModalModule.forRoot()
  ],
  exports: [
    MatSelectModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatChipsModule,
    MatCardModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatMenuModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatExpansionModule,
    MatTabsModule
  ],
  declarations: [],
  providers: [
    { provide: MAT_CHECKBOX_CLICK_ACTION, useValue: 'check' }
  ]
})
export class MaterialModule { }
