import { Component, OnInit, Renderer2, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Overlay, overlayConfigFactory, DialogRef } from 'ngx-modialog';
import { Modal, BSModalContext, } from 'ngx-modialog/plugins/bootstrap';
import { TranslateService } from "@ngx-translate/core";


@Component({
    selector: 'confirmation',
    templateUrl: './confirmation.component.html'
})
export class ConfirmationComponent implements OnInit {

    @Output() action = new EventEmitter();
    @Input() actionCB: Function;

    constructor(public form: FormBuilder,
        public modal: Modal,
        public dialogRef: DialogRef<any>,
        public renderer: Renderer2,
        public translate: TranslateService
    ) { }

    public onConfirm() {
        this.onCancel();
    }

    public onCancel() {
        this.modal.overlay.closeAll();
        this.renderer.removeClass(document.body, 'modal-open');
    }

    ngOnInit() {
    }

}
