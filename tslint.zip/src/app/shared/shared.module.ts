import { NgModule } from '@angular/core';
import { MaterialModule } from './modules/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppHttpInterceptor } from './interceptors/app.http.interceptor';
import { NumberOnlyDirective } from './directives/number-only.directive';
import { AlphaOnlyDirective } from './directives/alpha-only.directive';
import { BlockCopyPasteDirective } from './directives/block-copy-paste.directive';
import { KeysPipe } from './pipes/keys.pipe';
import { ConfirmationComponent } from './modal-popup/confirmation.component';

@NgModule({
  declarations: [
    NumberOnlyDirective,
    AlphaOnlyDirective,
    ConfirmationComponent,
    KeysPipe,BlockCopyPasteDirective
  ],
  entryComponents: [
    ConfirmationComponent,
  ],
  imports: [
    TranslateModule,
    NgSelectModule
  ],
  exports: [
    MaterialModule,
    TranslateModule,
    NgSelectModule,
    NumberOnlyDirective,
    AlphaOnlyDirective,
    KeysPipe,
    ConfirmationComponent,BlockCopyPasteDirective
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AppHttpInterceptor, multi: true },
  ]
})

export class SharedModule { }
