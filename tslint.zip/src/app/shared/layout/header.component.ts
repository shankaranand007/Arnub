import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Router } from '@angular/router';

import { AppService } from '../../app.service';
import { appConst } from '../../app.const';
import { appConfig } from '../../app.config';
import { ToastContainerDirective, ToastrService } from 'ngx-toastr';
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
    hide: string;
    @ViewChild(ToastContainerDirective) toastContainer: ToastContainerDirective;
    public isLangRtl :boolean= false;
    appDirection:any='ltr';
    constructor(public router: Router,public toastrService: ToastrService,
                public translate: TranslateService,
                public appService: AppService) {
                    this.toastrService.overlayContainer = this.toastContainer;
        translate.addLangs(['en', 'ar']);
        translate.setDefaultLang('en');
        const browserLang = 'en';
        translate.use(browserLang.match(/en|ar/) ? browserLang : 'en');
        this.hide = window.location.href.substr(window.location.href.lastIndexOf('/')).trim();
        console.log(this.hide,window.location.href.substr(window.location.href.lastIndexOf('/')).trim())
    }

    public selectedLanguage = 'en';
    public userProfilePic: any;
    alerts: any;
    unread: any = 0;
    interval = appConfig.INTERVAL;
    public langObj = [
        {
            val: 'en',
            name: 'English'
        },
        {
            val: 'ar',
            name: 'عربى'
        },
    ]
    public selectedLang = 'lang1';


    public switchLanguage(language: string) {
        this.selectedLanguage = language;
        this.translate.use(language);
        this.appService.setLanguage(language);
        appConst.LAN = language;
    }

    public getUserProfilePic() {
        const filePath = this.appService.userData.profilePic;
        if (!filePath) { return; }
        this.appService.getUserProfilePic(filePath).subscribe(
            res => {
                this.userProfilePic = 'data:image/jpg;base64,' + res;
            }
        );
    }

    public manageProfile() {
        // TODO
    }

    public changePassword() {
        // TODO
    }

    public logout() {
        this.appService.logoutUser({});
    }

    public eventListener() {
        this.appService.userLoggedIn.subscribe(() => {
            this.getUserProfilePic();
        });
        this.appService.userLoggedOut.subscribe(() => {
            this.router.navigateByUrl('/login');
        });
    }

    log() {
        /* console.log('Nothing'); */
    }

    changeLanguage(event) {
        this.translate.use(event);
        if(event ==="ar"){
            document.body.style.direction= "rtl";
            document.body.style.unicodeBidi = "bidi-override";
           // this.cssUrl = '../assets/styles/common-rtl.css';
           this.isLangRtl = true;
           this.appDirection = 'rtl';
        }
        else{
            document.body.style.direction= "ltr";
            document.body.style.unicodeBidi = "normal";
            this.isLangRtl = false;
            this.appDirection = 'ltr';
       }
    }

    ngOnInit() {
        this.selectedLanguage = this.translate.currentLang;
        this.eventListener();
    }
}
