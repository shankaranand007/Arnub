export class WorkList {
    refNo: string = "";
    workername: string = "";
    activity: string = "";
    lossdate: any ="";
    approveddate: any="";
}