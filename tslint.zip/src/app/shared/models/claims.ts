export class ClaimsList {
    fromDate: any = '';
    toDate: any = '';
    claimNo: String = '';
    certificateNo: String = '';
    emiratesId: String = '';
    batchNo: String = '';
    claimLaunchDate: String = '';
    employee: String = '';
    employeeType: String = '';
    employerName: String = '';
    claimStatus: String = '';
    department: String = '';
    division: String = '';
}

export class ClaimsListQueryParam {
    offset: any;
    limit: any;
}


