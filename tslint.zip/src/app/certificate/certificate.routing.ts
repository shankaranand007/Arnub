import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { appConst } from './../app.const';
import { CertificateComponent } from './certificate.component';
import { SharedModule } from './../shared/shared.module';
import { ModalModule } from 'ngx-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';

const certifiacteRoutes: Routes = [
    { path: '', component: CertificateComponent },
];

@NgModule({
    imports: [RouterModule.forChild(certifiacteRoutes),
        ModalModule.forRoot()
    ],
    exports: [RouterModule,SharedModule,ReactiveFormsModule],
   
})

export class CertificateRoutesModule { }
