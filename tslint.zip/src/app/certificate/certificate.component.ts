import { Component, OnInit,ViewChild,TemplateRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import {DomSanitizer,SafeResourceUrl} from '@angular/platform-browser'
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router,RouterModule} from '@angular/router';
import { HttpClient } from '@angular/common/http';
// import { appConfig } from '../app.config';
// import { appConfig } from '../../assets/env.prod';
import { appConfig } from './../../environments/environment';
import { ElementRef } from '@angular/core';
@Component({
  selector: 'app-certificate',
  templateUrl: './certificate.component.html',
  styleUrls: ['./certificate.component.scss']
})
export class CertificateComponent implements OnInit {
  appconfig: any = appConfig;
public show:boolean = false;
  modalRef: BsModalRef;
  certificateform :FormGroup;
  downloadOption :FormGroup;
  downloadUrl :FormGroup;
  model:any={};

  @ViewChild('certificateDownload') public certificateDownload: TemplateRef<any>;
  @ViewChild('Download') public Download: TemplateRef<any>;
  @ViewChild('labour') labourID:ElementRef; 
  @ViewChild('emirates') emiratesID:ElementRef; 
  
  public dialogRef: MatDialogRef<any>;
  constructor(public domSanitizer:DomSanitizer, public dialog: MatDialog ,public formBuilder : FormBuilder,private router:Router,public http: HttpClient) { 
    this.certificateform = this.formBuilder.group({
      emirates:[''],
      labour:['',Validators.required]

    });
    this.downloadOption = this.formBuilder.group({
      downMobNumber:['',Validators.required]

    });
    this.downloadUrl = this.formBuilder.group({
      tt:[''],
      OTP:['',Validators.required]

    })
  }

  downdata(){
    console.log("down load the data ")
    this.show = !this.show;
    
    this.dialogRef = this.dialog.open(this.certificateDownload,{width:'400px'});


    
  }
  closeCertificate(){
    this.dialogRef.close(this.Download);
    this.dialogRef.close(this.certificateDownload);
  }

  openModal(){
    console.log('open model');
    this.dialogRef = this.dialog.open(this.Download,{width:'400px'});
  }
   download(){
    //  this.model.regMobile = this.model.mobile;   
    console.log(this.model)
    this.dialogRef.close(this.certificateDownload);
     this.dialogRef = this.dialog.open(this.Download,{width:'400px'});
   }

   downloadDoc(){
      
  console.log("important",this.emiratesID.nativeElement.value.trim(),this.labourID.nativeElement.value.trim())
    let download_pdf = this.appconfig.API_BASE_URL+'/api/certificate/download?emiratesId='+ this.emiratesID.nativeElement.value +'&labourReferenceNo='+this.labourID.nativeElement.value.trim();
      console.log(download_pdf.trim())
    var redirect = <HTMLAnchorElement>document.createElement("a"); 
      document.body.appendChild(redirect); 
      redirect.href = download_pdf.trim();
      redirect.target = '_blank'; 
      redirect.click();
      this.dialogRef.close(this.Download);
      this.dialogRef.close(this.certificateDownload);
   }
  ngOnInit() {
  }

}
