import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CertificateRoutesModule } from './certificate.routing';
import { CertificateComponent } from './certificate.component';
import { SharedModule } from './../shared/shared.module';
import { ModalModule } from 'ngx-bootstrap';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
@NgModule({
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule,
    CertificateRoutesModule,
    SharedModule,
    ModalModule.forRoot()
  ],
  declarations: [CertificateComponent],
  entryComponents: [
    CertificateComponent,
],
})
export class CertificateModule { }
