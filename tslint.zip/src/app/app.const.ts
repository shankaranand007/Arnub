export const appConst = {
    LAN: 'en',
    ROUTES: {
        LOGIN: 'login',
        HOME: 'home',
        DASHBOARD: 'dashboard',
        MASTER: 'master',
        CLAIMS: 'claims',
        CLAIMSLIST: 'claimslist',
        CLAIMSSUMMARY: 'summary',
        CLAIMSREGISTER: 'registration',
        CLAIMSPAYMENT: 'payment',
        CLAIMSINSURER: 'insurer',
        CLAIMSRECOVERY: 'recovery',
        REPORTS: 'reports',
        PROCESS: 'process',
        UNDERWRITING: 'underwriting',
        LIST: 'list',
        CREATE: 'create/:id',
        PARAMS2: 'redirect/:id/:version',
        PARAMS: 'redirect/:id',
        WORKBASKET: 'workbasket',
        RESET: 'reset',
        RECONCILIATION: 'reconciliation',
        CERTIFICATE: 'certificate-download',
        ALLOCATION: 'allocation',
        TRANSFERS: 'tranasfer',
        NOTES: 'notes'
    },

    DATE_FORMAT: {
        API: 'YYYY-MM-DDThh:mm:ss',
        DATE_TIME: 'YYYY-MM-DD hh:mm:ss A',
        DATE: 'YYYY-MM-DD'
    },

    ERROR_MSG: {
        BAD_REQ: 'Bad Request',
        INTERVAL_SERVER_ERROR: 'Internal Server Error',
        ENTITY_NOT_FOUND: 'Error Code:452 ENTITY NOT FOUND IN DATABASE',
        INVALID_CREDENTIALS: 'Error Code:453 INVALID CREDENTIALS : INCORRECT USERID OR PASSWORD',
        BAD_CREDENTIALS: 'Bad credentials'
    },

    STATUS: {
        OPEN: 'Open',
        REVIEWED: 'Reviewed',
        APPROVED: 'Approved'
    },

    CLAIMS: {
        LIMIT: '10',
        OFFSET: '0',
        SUBTRACTMONTH: '1',
        EXPORTEXCELNAME: 'ClaimsReport',
        NODATAMESSAGE: '<div><span>No Data Found</span></div>',
        REOPENCLAIM: 'Re-open Claim',
        CLOSECLAIM: 'Close Claim',
        DECLINECLAIM: 'Decline Claim',
        REOPEN: 'reopen',
        CLOSE: 'close',
        DECLINE: 'decline',
        UPLOADIMAGEACCEPTFORMAT: [
            'image/jpeg',
            'image/png',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          ]
   },

};
