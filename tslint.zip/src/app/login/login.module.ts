import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScrollbarModule } from 'ngx-scrollbar';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { LoginService } from './login.service';
import { LoginComponent } from './login.component';
import { ResetComponent } from './reset/reset.component';
import { LoginRouting } from './login.routing';
//  import { RegistrationValidator } from "./register.validator";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ScrollbarModule,
        RouterModule,
        SharedModule,
        LoginRouting
    ],
    exports: [],
    declarations: [
        LoginComponent,
        ResetComponent
    ],
    providers: [
        LoginService
    ],
})
export class LoginModule { }
