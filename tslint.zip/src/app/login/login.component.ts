import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { LoginService } from './login.service';
import { AppService } from '../app.service';
import { appConst } from '../app.const';
import { TranslateService } from '@ngx-translate/core';
import { ViewChild } from '@angular/core';
import { TemplateRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';

@Component({
    selector: 'app-login',
    templateUrl: 'login.component.html',
    styleUrls: ['./loginStyle.scss'],
})

export class LoginComponent implements OnInit {
    @ViewChild('forgot') public forgot: TemplateRef<any>;
    public dialogRef: MatDialogRef<any>;
    public user: FormGroup;
    public formSubmitted = false;
    public isValidUser: boolean;
    public routePath: any;
    public inValidCredentials: any;
    constructor(public router: Router,
        public form: FormBuilder, public dialog: MatDialog,
        public appService: AppService,
        public route: ActivatedRoute,
        public loginService: LoginService,
        public translate: TranslateService) {
        this.initUserForm();
    }

    public initUserForm() {
        this.user = this.form.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
        this.isValidUser = true;
    }

    public login() {
        this.routePath = this.route.snapshot.routeConfig.path;
        const data = this.user.value;
        this.loginService.authenticate(data).subscribe(
            res => {
                console.log(res);
                 (res['isFirstLogin'] === 'N')?this.successLogin(res):(res['isFirstLogin'] === 'Y')?this.successReset(res):console.log("login issue");
                // this.successLogin(res);
            },
            err => {
                this.failureLogin(err);
            }
        );
    }

    public successLogin(res) {

        this.isValidUser = true;
        this.appService.createLoginSession(res);
        this.router.navigateByUrl('/home/master');
    }
    public successReset(res) {
        this.isValidUser = true;
        this.appService.createLoginSession(res);
        this.router.navigateByUrl('/login/reset');
    }

    public failureLogin(err) {
        console.log(err)
        this.isValidUser = false;
        setTimeout(() => { this.isValidUser = true; }, 6000);
        this.inValidCredentials = (err) ? err['error']['errors'][0] : 'Server not working';
    }
    onForgotPassword() {
        this.dialogRef = this.dialog.open(this.forgot);
    }
    onCloseCancel() {
        // this.dialogRef = this.dialog.close(this.forgot);
        this.dialogRef.close(this.forgot);
    }
    ngOnInit() {
        (this.appService.isUserAuthenticated) ? this.router.navigateByUrl('/home/master') : sessionStorage.clear();
    }
}
