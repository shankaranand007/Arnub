import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { LoginService } from '../login.service';
import { AppService } from '../../app.service';
import { appConst } from '../../app.const';
import { RegistrationValidator } from '../register.validator';
import { TranslateService } from '@ngx-translate/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.scss']
})
export class ResetComponent implements OnInit {
  public user: FormGroup;
  public formSubmitted = false;
  public isValidUser: boolean;
  public routePath: any;
  public showPassword = false;

  model: any = {};
  registrationFormGroup: FormGroup;
  passwordFormGroup: FormGroup;
  constructor(public appService: AppService, public formBuilder: FormBuilder, public router: Router, public translate: TranslateService, public loginService: LoginService, ) {
    this.passwordFormGroup = this.formBuilder.group({
      password: ['', Validators.required],
      repeatPassword: ['', Validators.required]
    }, {
        validator: RegistrationValidator.validate.bind(this)
      });
    this.registrationFormGroup = this.formBuilder.group({
      Old_Password: ['', Validators.required],
      passwordFormGroup: this.passwordFormGroup
    });
  }
  ngOnInit() {
  }
  resetPassword() {
    this.loginService.resetPassword(this.model)
      .subscribe(data => {
        (data) ? this.router.navigate(['/home/master']) : alert('issue');
      })
  }
  password_toggle(){
    this.showPassword = !this.showPassword;
  }
  onForgotPassword(){
    console.log("forgot password")
  }
}
