import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { LoginComponent } from './login.component';
import { ResetComponent } from './reset/reset.component';
import { AuthGuardService as AuthGuard } from '../shared/services/auth.guard.service';
import { appConst } from '../app.const';

const Log: Routes = [
    { path: '', component: LoginComponent },
    { path: appConst.ROUTES.RESET, component: ResetComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(Log)],
    exports: [RouterModule],
})

export class LoginRouting { }
