export const appConfig = {
    // API_BASE_URL: 'http://192.168.8.91:8081/mol',
      API_BASE_URL: 'http://192.168.8.91:8081/mol',
     INTERVAL: 600000
   };
   