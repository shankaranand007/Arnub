export const appConfig = {
  production: true,
  API_BASE_URL: 'http://192.168.8.91:8081/mol',
};
